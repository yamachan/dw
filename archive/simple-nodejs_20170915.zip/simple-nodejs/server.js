var http = require("http");
var fs = require('fs');

function getType(_url) {
	var types = {
		".html": "text/html",
		".css": "text/css",
		".js": "text/javascript",
		".png": "image/png",
		".gif": "image/gif",
		".svg": "svg+xml"
	}
	for (var key in types) {
		if (_url.endsWith(key)) {
			return types[key];
		}
	}
	return "text/plain";
}

var basic_realm = "public/member/";
var basic_name = "simple-nodejs_member";
var basic_users = ["QWxhZGRpbjpvcGVuIHNlc2FtZQ=="];
function isUser(_auth) {
	for (var l=0; l<basic_users.length; l++) {
		if (basic_users[l] == _auth) {
			return true;
		}
	}
	return false;
}
function addUser(_id, _pw) {
	var auth = (new Buffer((_id + ':' + _pw).toString(), 'binary')).toString('base64');
	if (!isUser(auth)) {
		basic_users.push(auth);
	}
}
addUser("yamachan", "123");

var server = http.createServer(function (req, res) {
	var url = "public" + (req.url.endsWith("/") ? req.url + "index.html" : req.url);
	console.log(url); // for debug
	if (url.startsWith(basic_realm)) {
		var auth = req.headers["authorization"]||"";
		if (!auth.startsWith("Basic ") || !isUser(auth.substring(6))) {
			res.statusCode = 401;
			res.setHeader('WWW-Authenticate', 'Basic realm="' + basic_name + '"');
			res.end();
		}
	}
	if (!res.finished) {
		if (fs.existsSync(url)) {
			fs.readFile(url, (err, data) => {
				if (!err) {
					res.writeHead(200, {"Content-Type": getType(url)});
					res.end(data);
				} else {
					res.statusCode = 500;
					res.end();
				}
			});
		} else {
			res.statusCode = 404;
			res.end();
		}
	}
});

var port = process.env.PORT || 3000;
server.listen(port, function() {
  console.log("To view your app, open this link in your browser: http://localhost:" + port);
});
