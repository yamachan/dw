var http = require("http");
var https = require('https');
var fs = require('fs');

function getType(_url) {
	var types = {
		".html": "text/html",
		".css": "text/css",
		".js": "text/javascript",
		".png": "image/png",
		".gif": "image/gif",
		".svg": "svg+xml"
	}
	for (var key in types) {
		if (_url.endsWith(key)) {
			return types[key];
		}
	}
	return "text/plain";
}

var basic_realm = "public/member/";
var basic_name = "simple-nodejs_member";
var basic_users = ["QWxhZGRpbjpvcGVuIHNlc2FtZQ=="];
function isUser(_auth) {
	for (var l=0; l<basic_users.length; l++) {
		if (basic_users[l] == _auth) {
			return true;
		}
	}
	return false;
}
function addUser(_id, _pw) {
	var auth = (new Buffer((_id + ':' + _pw).toString(), 'binary')).toString('base64');
	if (!isUser(auth)) {
		basic_users.push(auth);
	}
}
addUser("yamachan", "123");

function writeContent(_res, _data, _type) {
	_type = _type ? _type : "text/plain";
	_res.writeHead(200, {"Content-Type": _type});
	_res.end(_data);
}
function writeError(_res, _code) {
	console.log("ERROR: " + _code); // for debug
	_res.statusCode = _code;
	_res.end();
}

var server = http.createServer(function (req, res) {
	var url = "public" + (req.url.endsWith("/") ? req.url + "index.html" : req.url);
	console.log(url); // for debug
	if (url.startsWith(basic_realm)) {
		var auth = req.headers["authorization"]||"";
		if (!auth.startsWith("Basic ") || !isUser(auth.substring(6))) {
			res.setHeader('WWW-Authenticate', 'Basic realm="' + basic_name + '"');
			writeError(res, 401);
		}
	}
	if (!res.finished) {
		if (url == "public/api/zen") {
			var opt = {hostname:'api.github.com', port:443, path:'/zen', headers:{'user-agent':'simple-nodejs'}, method:'GET'};
			https.get(opt, (r) => {
				var d = "";
				if (r.statusCode == 200) {
					r.on('data', (_chunk) => d += _chunk);
					r.on('end', () => writeContent(res, d));
				} else {
					writeContent(res, "ERROR: " + r.statusCode);
				}
			});
		} else if (fs.existsSync(url)) {
			fs.readFile(url, (err, data) => {
				if (!err) {
					writeContent(res, data, getType(url));
				} else {
					writeError(res, 500);
				}
			});
		} else {
			writeError(res, 404);
		}
	}
});

var port = process.env.PORT || 3000;
server.listen(port, function() {
  console.log("To view your app, open this link in your browser: http://localhost:" + port);
});
